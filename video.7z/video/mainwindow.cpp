﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "fileOperation.h"
#include <QStringListModel>
#include <iostream>
#include <QTimer>
#include <QStandardItemModel>
#include "webdataitem.h"
#include <QFont>
#include <QMessageBox>

#include <libtorrent/session.hpp>
#include <libtorrent/add_torrent_params.hpp>
#include <libtorrent/torrent_handle.hpp>
#include <libtorrent/alert_types.hpp>
#include <libtorrent/bencode.hpp>
#include <libtorrent/torrent_status.hpp>
#include<boost/make_shared.hpp>

using clk = std::chrono::steady_clock;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

void MainWindow::init(QHash<QString,QString>& source_web_link)
{
    this->source_web_link = source_web_link;
    initSourceWebList();
    initSearchDataList();
    initVideoTorrentList();
    search_box = new QLineEdit(this);
    search_box->setGeometry(200, 20, 200, 50);
    search_button = new QPushButton("搜索",this);
    search_button->setGeometry(450, 20, 100, 50);
    connect(search_button, &QPushButton::clicked, this, &MainWindow::searchClick);

    lable = new QLabel("搜索中", this);
    lable->setGeometry(600, 20, 100, 50);
    //lable->resize(200,200);
    QFont ft;
    ft.setPointSize(15);
    lable->setFont(ft);
    lable->hide();

    msearch = new WebSearch(source_web_link);
    initVideoView();
}

void MainWindow::destroy()
{
    qDebug()<< "destroy";
    //video_view->deinit();
    delete video_view;
    delete search_data_list;
    delete msearch;
    delete search_button;
    delete search_box;
    delete source_web_list;
    qDebug()<< "destroy success";
}

void MainWindow::initVideoView()
{
    video_view = new VideoView();
    video_view->init();
}

void MainWindow::initSourceWebList()
{
    source_web_list = new QListView(this);
    source_web_list->setGeometry(50, 20, 100, 200);
    QStringList list;//创建数据显示列表
    for (QHash<QString, QString>::const_iterator i = source_web_link.cbegin(); i != source_web_link.cend(); ++i) {
        qDebug() << "mainui :" <<i.key();
        list.append(i.key());
    }
    //使用数据列表创建数据显示模型
    QStringListModel* source_web_list_model = new QStringListModel(list);
    //source_web_list_model.setStringList(list);
    source_web_list->setModel(source_web_list_model);                   //设置模型到listview上
    source_web_list->setEditTriggers(QAbstractItemView::NoEditTriggers);
    source_web_list->setSpacing(2);
    connect(source_web_list,&QListView::clicked, this, &MainWindow::sourceWebListItemClick);
}

void MainWindow::initSearchDataList()
{
    search_data_list = new QListView(this);
    search_data_list->setGeometry(200, 100, 800, 500);
    search_data_list->setEditTriggers(QAbstractItemView::NoEditTriggers);
    QStandardItemModel *search_data_list_model = new QStandardItemModel();
    /*MuItemData itemData;
    itemData.name = "test";
    itemData.message = "test";
    itemData.link = "https://www.bt-tt.com/html/11/29867.html";
    QStandardItem *pItem = new QStandardItem();
    pItem->setData(QVariant::fromValue(itemData));
    search_data_list_model->appendRow(pItem);*/

    WebDataItem *pItemDelegate = new WebDataItem(this);
    search_data_list->setItemDelegate(pItemDelegate);
    search_data_list->setModel(search_data_list_model);
    connect(search_data_list, &QListView::clicked, this, &MainWindow::searchDataItemClick);
}

void MainWindow::initVideoTorrentList()
{
    web_video_tabwidget = new QTabWidget(this);
    web_video_tabwidget->setGeometry(1050, 100, 400, 500);
    /*video_torrent_list = new QListView(this);
    video_torrent_list->setGeometry(1050, 100, 400, 500);

    video_torrent_list->setEditTriggers(QAbstractItemView::NoEditTriggers);
    video_torrent_list->setSpacing(2);
    connect(video_torrent_list,&QListView::clicked, this, &MainWindow::videoTorrentListItemClick);*/
}


MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::searchClick()
{
    //qDebug()<< "searchClick";
    QString search_video_name = search_box->text();

    video_view->show();
    video_view->startDownload("");

    if(search_video_name != ""){
        lable->show();
        search_button->setEnabled(false);
        msearch->getSearchData(search_video_name, web_data);
        search_button->setEnabled(true);
        lable->hide();
        QModelIndex qindex = source_web_list->model()->index(0,0);
        source_web_list->clicked(qindex);
        source_web_list->setCurrentIndex(qindex);
    }
}

void MainWindow::sourceWebListItemClick(const QModelIndex &index)
{
    QStandardItemModel *search_data_list_model = dynamic_cast<QStandardItemModel*>(search_data_list->model());
    search_data_list_model->clear();
    qDebug()<<"listView pos.row:"<<index.row() << index.data().toString();
    QVector<MuItemData> data = web_data[index.data().toString()];
    for (int i=0; i< data.size(); ++i) {
        qDebug()<<data[i].name << data[i].link;
        QStandardItem *pItem = new QStandardItem;
        MuItemData itemData;
        itemData.name = data[i].name;
        itemData.message = data[i].message;
        itemData.icon_data = data[i].icon_data;
        itemData.link = data[i].link;
        pItem->setData(QVariant::fromValue(itemData), Qt::UserRole+1);
        search_data_list_model->appendRow(pItem);
    }
}

void MainWindow::searchDataItemClick(const QModelIndex &index)
{
    MuItemData itemData = (index.data(Qt::UserRole + 1).value<MuItemData>());
    qDebug()<<"searchDataItemClick pos.row:"<<index.row() << itemData.link;
    web_video_tabwidget->clear();
    video_torrent_data.clear();
    QHash<QString,QList<QString>> video_name_hash;
    msearch->getVideoTorrentList(itemData.link, video_torrent_data, video_name_hash);
    for (QHash<QString,QHash<QString,QString>>::const_iterator i = video_torrent_data.cbegin(); i != video_torrent_data.cend(); ++i) {
        QStringList list;//创建数据显示列表
        /*QHash<QString, QString> hash_list = i.value();
        for (QHash<QString, QString>::const_iterator i = hash_list.cbegin();i!=hash_list.cend(); ++i) {
            //qDebug() << "mainui :" <<i.key();
            list.append(i.key());
        }*/
        QList<QString> video_name_list = video_name_hash[i.key()];
        for (int i = 0; i < video_name_list.size(); i++) {
            list.append(video_name_list[i]);
        }
        //qSort(list.begin(),list.end(),compareBarData);

        QStringListModel* video_torrent_data_list_model = new QStringListModel(list);
        //source_web_list_model.setStringList(list);
        QListView *video_torrent_list = new QListView(this);
        video_torrent_list->setGeometry(1050, 100, 400, 500);
        video_torrent_list->setEditTriggers(QAbstractItemView::NoEditTriggers);
        video_torrent_list->setSpacing(2);
        connect(video_torrent_list,&QListView::clicked, this, &MainWindow::videoTorrentListItemClick);
        video_torrent_list->setModel(video_torrent_data_list_model);
        web_video_tabwidget->addTab(video_torrent_list, i.key());
    }

}

void MainWindow::videoTorrentListItemClick(const QModelIndex &index)
{
    QString current_tab_name = web_video_tabwidget->tabText(web_video_tabwidget->currentIndex());
    qDebug() << "current tab" <<current_tab_name;
    QHash<QString,QString> current_tab_hash =  video_torrent_data[current_tab_name];
    qDebug() << "index.data()" <<index.data();
    //current_index = current_tab_hash[index.data().toString()];
    //current_index = index.row();
    QString video_torrent = current_tab_hash[index.data().toString()];


    qDebug() << "video_torrent" <<video_torrent;
    video_view->show();
    video_view->startDownload(video_torrent);

}
