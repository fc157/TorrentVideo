﻿#include "mainwindow.h"
#include <QApplication>
#include "fileOperation.h"
#include <QScreen>
#include <QSize>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    FileOperation mf;
    QHash<QString,QString> link_data;
    mf.getWebLink(link_data);
    qDebug() << "link_data size:" << link_data.size() << ":"<<link_data;

    MainWindow w;
    w.init(link_data);
    QScreen* screen = QGuiApplication::primaryScreen();
    QSize screen_size = screen->size();
    w.resize(screen_size.width()*2/3, screen_size.height()*2/3);
    w.show();
    a.exec();
    w.destroy();
    return 0;
}
