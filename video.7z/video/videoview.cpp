﻿#include "videoview.h"
#include "ui_videoview.h"
#include <QFileDialog>
VideoView::VideoView(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VideoView)
{
    ui->setupUi(this);
}
void VideoView::init()
{
    initVideo();
    my_torrent = new MyTorrent();
    my_torrent->init();

    connect(my_torrent, &MyTorrent::startSignal, this, &VideoView::startPlay);
    connect(my_torrent, &MyTorrent::playSignal, this, &VideoView::continuePlay);
    connect(ui->test, &QPushButton::clicked, my_torrent, &MyTorrent::testClick);
}
void VideoView::continuePlay()
{
    //m_pPlayer->setMedia(QUrl::fromLocalFile(file_path));
    //ui->slider->setValue(0);
    m_pPlayer->play();
    m_pPlayer->setPosition(current_position);

}

void VideoView::initVideo()
{
    m_pPlayer = new QMediaPlayer;
    m_pPlayerWidget = new QVideoWidget;
    m_pPlayer->setVideoOutput(m_pPlayerWidget);
    ui->verticalLayout->addWidget(m_pPlayerWidget);

    m_pPlayerWidget->setAutoFillBackground(true);
    QPalette qplte;
    qplte.setColor(QPalette::Window, QColor(0,0,0));
    m_pPlayerWidget->setPalette(qplte);
    //载入
    connect(ui->BtnLoad, SIGNAL(clicked()), this, SLOT(OnSetMediaFile()));
    //播放
    connect(ui->BtnPlay, SIGNAL(clicked()), m_pPlayer, SLOT(play()));
    //停止
    connect(ui->BtnStop, SIGNAL(clicked()), m_pPlayer, SLOT(stop()));

    connect(m_pPlayer, SIGNAL(stateChanged(QMediaPlayer::State)), this, SLOT(OnStateChanged(QMediaPlayer::State)));
    connect(m_pPlayer, SIGNAL(mediaStatusChanged(QMediaPlayer::MediaStatus)), this, SLOT(OnMediaStatusChanged(QMediaPlayer::MediaStatus)));
    connect(m_pPlayer, SIGNAL(error(QMediaPlayer::Error)), this, SLOT(OnError(QMediaPlayer::Error)));
    ui->BtnStop->setEnabled(false);
    //设置滑块行为
    m_bReLoad = true;
    ui->slider->setEnabled(false);
    connect(m_pPlayer, SIGNAL(positionChanged(qint64)), this, SLOT(OnSlider(qint64)));
    connect(m_pPlayer, SIGNAL(durationChanged(qint64)), this, SLOT(OnDurationChanged(qint64)));
    connect(ui->slider, &PlayerSlider::sigProgress, this, &VideoView::updatePosition);
}

void VideoView::deinit()
{
    my_torrent->deinit();
    delete my_torrent;
    delete m_pPlayerWidget;
    m_pPlayer->stop();
    delete m_pPlayer;
}

void VideoView::startDownload(QString video_torrent)
{
    my_torrent->startDownload();
}

void VideoView::updatePosition(qint64 position)
{
    qDebug() << "updatePosition :" << position << "; duration: " << duration;
    //m_pPlayer->setPosition(position);
    current_position = position;
    //m_pPlayer->stop();
    m_pPlayer->pause();
    float bili = (float)position/(float)duration;
    my_torrent->updatePosition(bili);
}

void VideoView::startPlay()
{
    file_path = "D:/WorkSoftware/QT/project/myvideo/build-video-Desktop_Qt_5_15_2_MSVC2019_64bit-Release/Sintel/Sintel.mp4";
    qDebug() << "file path:" <<file_path;
    m_pPlayer->setMedia(QUrl::fromLocalFile(file_path));
    m_bReLoad = true;
    ui->slider->setValue(0);
    m_pPlayer->play();
}

void VideoView::OnSetMediaFile(void)
{
    QFileDialog dialog(this);
    dialog.setFileMode(QFileDialog::AnyFile);
    QStringList fileNames;
    if (dialog.exec())
        fileNames = dialog.selectedFiles();

    if(!fileNames.empty())
    {
        file_path = fileNames[0];
        qDebug() << "file path:" <<fileNames[0];
        m_pPlayer->setMedia(QUrl::fromLocalFile(fileNames[0]));
        m_bReLoad = true;
        ui->slider->setValue(0);
    }
}


void VideoView::OnSlider(qint64 i64Pos)
{
    //qDebug() << "OnSlider : " << i64Pos;
    ui->slider->setProgress(i64Pos);
}

void VideoView::OnDurationChanged(qint64 i64Duration)
{
    if(i64Duration > 0 && m_bReLoad)
    {
        duration = i64Duration;
        qDebug() << "OnDurationChanged  : " << i64Duration;
        ui->slider->setRange(0, i64Duration);
        m_bReLoad = false;
    }
}

void VideoView::OnStateChanged(QMediaPlayer::State enumState)
{
    qDebug() << "OnStateChanged :" << enumState;
    if(QMediaPlayer::StoppedState == enumState)
    {
        ui->BtnPlay->setEnabled(true);
        ui->BtnStop->setEnabled(false);
        ui->slider->setEnabled(false);
    }
    else if(QMediaPlayer::PlayingState == enumState)
    {
        ui->BtnPlay->setEnabled(false);
        ui->BtnStop->setEnabled(true);
        ui->slider->setEnabled(true);
    }
}

void VideoView::OnMediaStatusChanged(QMediaPlayer::MediaStatus state)
{
    qDebug() << "OnMediaStatusChanged :" << state;
}
void VideoView::OnError(QMediaPlayer::Error state)
{
    qDebug() << "OnError :" << state;
}

VideoView::~VideoView()
{
    delete ui;
}

