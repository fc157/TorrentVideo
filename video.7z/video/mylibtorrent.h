#ifndef MYLIBTORRENT_H
#define MYLIBTORRENT_H


class MyLibtorrent
{
public:
    MyLibtorrent();
};

#endif // MYLIBTORRENT_H
