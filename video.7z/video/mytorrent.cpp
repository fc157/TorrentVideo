﻿#include "mytorrent.h"
#include <QCoreApplication>
#include <QDebug>
MyTorrent::MyTorrent()
{

}
lt::storage_mode_t allocation_mode = lt::storage_mode_sparse;
std::string save_path(".");
int torrent_upload_limit = 0;
int torrent_download_limit = 0;
std::string monitor_dir;
int poll_interval = 5;
int max_connections_per_torrent = 50;
bool seed_mode = false;
bool stats_enabled = false;
int cache_size = -1;

bool share_mode = false;
bool disable_storage = false;

bool quit = false;
//打印出来的大小是以byte为单位
std::string to_hex(lt::sha1_hash const& s)
{
    std::stringstream ret;
    ret << s;
    return ret.str();
}

std::string path_append(std::string const& lhs, std::string const& rhs)
{
    if (lhs.empty() || lhs == ".") return rhs;
    if (rhs.empty() || rhs == ".") return lhs;

#if defined(TORRENT_WINDOWS) || defined(TORRENT_OS2)
#define TORRENT_SEPARATOR "\\"
    bool need_sep = lhs[lhs.size()-1] != '\\' && lhs[lhs.size()-1] != '/';
#else
#define TORRENT_SEPARATOR "/"
    bool need_sep = lhs[lhs.size()-1] != '/';
#endif
    return lhs + (need_sep?TORRENT_SEPARATOR:"") + rhs;
}

std::string resume_file(lt::sha1_hash const& info_hash)
{
    return path_append(save_path, path_append(".resume"
                                              , to_hex(info_hash) + ".resume"));
}

bool load_file(std::string const& filename, std::vector<char>& v
               , int limit = 8000000)
{
    std::fstream f(filename, std::ios_base::in | std::ios_base::binary);
    f.seekg(0, std::ios_base::end);
    auto const s = f.tellg();
    if (s > limit || s < 0) return false;
    f.seekg(0, std::ios_base::beg);
    v.resize(static_cast<std::size_t>(s));
    if (s == std::fstream::pos_type(0)) return !f.fail();
    f.read(v.data(), v.size());
    return !f.fail();
}

void set_torrent_params(lt::add_torrent_params& p)
{
    p.max_connections = max_connections_per_torrent;
    p.max_uploads = -1;
    p.upload_limit = torrent_upload_limit;
    p.download_limit = torrent_download_limit;

    if (seed_mode) p.flags |= lt::torrent_flags::seed_mode;
    if (disable_storage) p.storage = lt::disabled_storage_constructor;
    if (share_mode) p.flags |= lt::torrent_flags::share_mode;
    p.save_path = save_path;
    p.storage_mode = allocation_mode;
}

void MyTorrent::init()
{
    std::string torrent_file_path = "D:/WorkSoftware/QT/project/torrent/Sintel.torrent";
    lt::error_code ec;
    ti = std::make_shared<lt::torrent_info>(torrent_file_path, ec);
    if (ec)
    {
        std::printf("failed to load torrent \"%s\": %s\n"
                    , torrent_file_path.c_str(), ec.message().c_str());
    }
    qDebug() << "total_size:" <<ti->total_size();


    qDebug() << "num_files :" <<ti->num_files();
    lt::file_storage ff = ti->files();

    //qDebug() << "v1:" << ti->v1();
    //qDebug() << "v2:" << ti->v2();

    QString q_str;
    for (int var = 0; var < ti->num_files(); ++var) {
        std::string ss(ff.file_name(var));
        q_str = QString::fromStdString(ss);
        //qDebug() << "file name "<<var<<":"<<q_str;
        //qDebug() << "file_size "<<var<<":"<<ff.file_size(var);
        q_str = q_str.mid(q_str.size() - 3 , 3);
        //qDebug() << "q_str :"<<q_str;
        if(q_str.compare("mp4") == 0)
        {
            std::tuple mtuple = lt::aux::file_piece_range_inclusive(ff, var);
            video_piece_start_index = std::get<0>(mtuple);
            video_piece_end_index = std::get<1>(mtuple);
            video_piece_end_index--;
            //qDebug() << "start:" << video_piece_start_index << "; end:" << video_piece_end_index;
        }
    }

}
void MyTorrent::deinit()
{

}

void MyTorrent::startDownload()
{
    lt::add_torrent_params p;
    std::vector<char> resume_data;
    lt::error_code ec;
    if (load_file(resume_file(ti->info_hash()), resume_data))
    {
        p = lt::read_resume_data(resume_data, ec);
        if (ec) std::printf("  failed to load resume data: %s\n", ec.message().c_str());
    }
    set_torrent_params(p);

    unsigned int high_down_size = ti->total_size()*0.03;
    int high_down_picec_size = high_down_size/ti->piece_length();
    qDebug() << "high_down_picec_size:" <<high_down_picec_size;
    p.ti = ti;
    p.flags &= ~lt::torrent_flags::duplicate_is_error;
    h = ses.add_torrent(std::move(p));
    for (int var = 0; var <= high_down_picec_size; ++var) {
        h.piece_priority(var,lt::top_priority);
        h.set_piece_deadline(var,1);
        h.piece_priority(video_piece_end_index-var,lt::top_priority);
        h.set_piece_deadline(video_piece_end_index-var,1);
    }
    is_download = true;
    qDebug() << "have_piece(video_piece_end_index) :" <<h.have_piece(video_piece_end_index);
    qDebug() << "have_piece(video_piece_start_index) :" <<h.have_piece(video_piece_start_index);
    /*while( 1 )
    {
        QCoreApplication::processEvents();
        if( h.have_piece(high_down_picec_size) && h.have_piece(video_piece_end_index) )
        {
            emit startSignal();
            break;
        }
    }*/

    int var = video_piece_start_index;
    int endvar = video_piece_end_index;
    while(var < high_down_picec_size)
    {
        QCoreApplication::processEvents();
        if(h.have_piece(var) && h.have_piece(video_piece_end_index - var)){
            var++;
        }
    }
    emit startSignal();
    int tmp = 1;
    for (int var = high_down_picec_size+1; var <= video_piece_end_index-high_down_picec_size; ++var) {
        h.piece_priority(var,lt::default_priority);
        h.set_piece_deadline(var,tmp++);
    }

    qDebug() << "send startSignal";

}

void MyTorrent::updatePosition(float bili)
{
    qDebug() << "updatePosition :" << bili;
    //实现点哪下哪
    int index = (video_piece_end_index - video_piece_start_index)*bili;
    qDebug() << "index :" << index;
    h.clear_piece_deadlines();

    /*lt::file_storage ff = ti->files();
    qDebug() << "piece length:" << ff.piece_length();
    std::vector<lt::file_slice> f_map = ff.map_block(index , 0, 254260);
    qDebug() << "f_map.size():" <<f_map.size();
    for (int var = 0; var < f_map.size(); ++var) {
        qDebug() << "file_index:" << f_map[var].file_index
                 << "; offset: " << f_map[var].offset
                 << "; size:" << f_map[var].size;
    }*/
    //ff.map_block(1 , 0, 254260);输出结果如下
    //file_index: 5 ; offset:  123188 ; size: 254260
    //表示文件5第0片占据大小123188，因为还有其他文件占了第0片。所以第1片的偏移，表示的是当前文件的偏移

    if(index - MIN_DOWNLOAD_PIECE_LENGTH > 0)
        index = index - MIN_DOWNLOAD_PIECE_LENGTH;
    else
        index = 0;

    int count = 0;
    int need_size = MIN_DOWNLOAD_PIECE_LENGTH*5; //前面1倍，后面4倍
    for(int var = index;var <= need_size; var++){
        h.piece_priority(var,lt::top_priority);
        h.set_piece_deadline(var,1);
    }
    int tmp_index = index;
    while(tmp_index < video_piece_end_index && count < need_size)
    {
        QCoreApplication::processEvents();
        if(h.have_piece(tmp_index)){
            tmp_index++;
            count++;
        }
    }
    int tmp = 1;
    for(;tmp_index <= video_piece_end_index; tmp_index++){
        h.piece_priority(tmp_index,lt::default_priority);
        h.set_piece_deadline(tmp_index,tmp++);
    }
    emit playSignal();

    //break;
    qDebug() << "send playSignal";
}

int MyTorrent::getVideoPieceStartIndex()
{
    return video_piece_start_index;
}
int MyTorrent::getVideoPieceEndIndex()
{
    return video_piece_end_index;
}

void MyTorrent::testClick()
{
    std::vector<lt::partial_piece_info> download_queue;
    h.get_download_queue(download_queue);
    qDebug() << "download_queue size:" << download_queue.size();

    for (int var = 0; var < download_queue.size(); ++var) {
        qDebug() << "piece_index:" << download_queue[var].piece_index << ";"
                 << "blocks_in_piece" << download_queue[var].blocks_in_piece << ";"
                 << "finished" << download_queue[var].finished << ";"
                 << "writing" << download_queue[var].writing << ";"
                 << "requested" << download_queue[var].requested << ";";
    }
}

