﻿#ifndef FILEOPERATION_H
#define FILEOPERATION_H

#include <QString>
#include <QHash>

class FileOperation
{
public:
    FileOperation();
    ~FileOperation();
    void getWebLink(QHash<QString,QString>& ret);

private:
    void parsingWebLink(QHash<QString,QString>& data, QString& source_data);
};

#endif // FILEOPERATION_H
