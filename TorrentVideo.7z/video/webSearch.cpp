﻿#include "webSearch.h"
#include <QDebug>
#include <QTextCodec>
#include <QSslSocket>
#include <QByteArray>
#include <QNetworkCookie>
#include <QNetworkProxy>
WebSearch::WebSearch()
{
    manager = new QNetworkAccessManager();

}
WebSearch::WebSearch(QHash<QString,QString>& web_link)
{
    manager = new QNetworkAccessManager();
    this->web_link = web_link;
    web_data = "";
    timer.setSingleShot(true);
    connect(&timer, &QTimer::timeout, [&]
            { search_result = false;;  eventLoop.quit(); });

    /*QNetworkProxy proxy;
    proxy.setType(QNetworkProxy::HttpProxy);
    proxy.setHostName("120.79.7.173");
    proxy.setPort(8888);
    manager->setProxy(proxy);*/
}
WebSearch::~WebSearch()
{
    delete manager;
}

void WebSearch::getSearchData(QString name, QHash<QString,QVector<MuItemData>>& ret_web)
{
    //getSearchDataForYyets(name);

    QVector<MuItemData> data;
    getSearchDataForBTtiantang(name, data);
    ret_web.insert("BT天堂", data);
}

void WebSearch::getSearchDataForBTtiantang(QString name, QVector<MuItemData>& vec_data)
{
    QString url_link = "https://www.bt-tt.com/e/search/";
    //qDebug()<<url_link;
    web_data = "";
    QUrl url(url_link);
    QNetworkRequest req;
    req.setUrl(url);
    req.setHeader(QNetworkRequest::ContentTypeHeader, "application/x-www-form-urlencoded");
    req.setHeader(QNetworkRequest::UserAgentHeader, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36");
    QList<QNetworkCookie> allcookies;
    QNetworkCookie cy("Hm_lvt_c11e70df18184f7263176ce90c8a9cc3","1688954092,1689141043,1689217243") ;
    QNetworkCookie cy1("XLA_CI","49f897a10825a7d7a725fb2d5ad9808e") ;
    QNetworkCookie cy2("cf_clearance","gxPvJKABzfOkh4fYmKcqXA0GO4wQ2VcOCGW2pL8Hj.Q-1691463278-0-1-ab06b8f.e4715e39.5db1346f-160.2.1691463278") ;
    allcookies.append(cy);
    allcookies.append(cy1);
    allcookies.append(cy2);
    req.setHeader(QNetworkRequest::SetCookieHeader, QVariant::fromValue(allcookies));

    req.setAttribute(QNetworkRequest::FollowRedirectsAttribute, true);
    qDebug()<< "search url :" <<req.url();
    qDebug()<< "search rawHeaderList :" <<req.rawHeaderList();

    search_result = true;
    QString form_data;
    form_data.append("show=title,newstext&");
    form_data.append(tr("keyboard=%1&").arg(name));
    form_data.append(tr("searchtype=%1").arg("影视搜索"));
    //qDebug()<<form_data;
    reply = manager->post(req, form_data.toUtf8());
    connect(reply,&QNetworkReply::finished,this,&WebSearch::replyFinished);
    //timer.start(8000);
    eventLoop.exec();
    //timer.stop();

    //web_data = reply->readAll();
    if(web_data == "" || web_data.length() <= 0){
        return;
    }
    //qDebug()<<web_data;
    //qDebug("web_data length: %d ", web_data.length());
    int start_index = web_data.indexOf(tr("%1</font>搜索结果").arg(name));
    int end_index = web_data.indexOf("<script src=/ads.js>");//<script src=/ads.js>
    qDebug("start_index: %d ", start_index);
    qDebug("end_index: %d ", end_index);
    web_data = web_data.mid(start_index,end_index-start_index);
    //qDebug("web_data length: %d ", web_data.length());
    int uri_length = 0;
    MuItemData item_data;
    int current_size = 0;
    while((start_index = web_data.indexOf("<a href=\"")) != -1)
    {
        start_index = start_index + 9;
        uri_length = 0;
        while(web_data[start_index+uri_length] != "\"")
        {
            uri_length++;
        }
        item_data.link = "https://www.bt-tt.com" + web_data.mid(start_index, uri_length);
        //qDebug() << item_data.link;
        start_index = start_index + uri_length + 12;
        uri_length = 0;
        while(web_data[start_index+uri_length] != "\"")
        {
            uri_length++;
        }
        url = web_data.mid(start_index, uri_length);
        req.setUrl(url);
        //item_data.iconPath =  web_data.mid(start_index, uri_length);
        //qDebug() << url;
        //<p>\n◎译　　名
        if((start_index = web_data.indexOf("<p>\n◎译　　名　")) != -1){
            //34
            uri_length = start_index-35;
            start_index = uri_length;
            while(web_data[start_index] != ">")
            {
                start_index--;
            }
            item_data.name = name + web_data.mid(start_index, uri_length-start_index);
        }
        web_data = web_data.mid(start_index,end_index-start_index);
        start_index = web_data.indexOf("</span>");
        web_data = web_data.mid(start_index,end_index-start_index);

        reply = manager->get(req);
        connect(reply,SIGNAL(finished()),&eventLoop,SLOT(quit()));
        eventLoop.exec();
        item_data.icon_data = reply->readAll();
        qDebug()<<item_data.name;
        vec_data.push_back(item_data);
        current_size++;
        if(current_size > 20)
            break;
    }

}

void WebSearch::getSearchDataForYyets(QString name)
{
    QString dmesg = web_link["人人影视"]+"keyword="+name+"&type=default";
    qDebug()<<dmesg;
    //qDebug()<<QSslSocket::supportsSsl();
    //qDebug()<<QSslSocket::sslLibraryBuildVersionString();
    web_data = "";
    startRequest( QUrl(dmesg));
    // 进入等待，但事件循环依然进行
    eventLoop.exec();
    //qDebug()<<web_data;
    if(web_data!=""){
        QJsonParseError jsonError;
        mQJsonDocument = QJsonDocument::fromJson(web_data.toUtf8(), &jsonError);
        if (jsonError.error != QJsonParseError::NoError) {
            //qDebug() << "Json格式错误！" << jsonError.error;
            return;
        }
        qDebug()<<mQJsonDocument["data"][0]["id"];
    }

}


//调用函数发送请求，参数是请求的服务器地址
//startRequest(QUrl("http://127.0.0.1:8000/test"));
void WebSearch::startRequest(const QUrl &requestedUrl)
{
    url = requestedUrl;
    QNetworkRequest req;
    req.setUrl(url);
    //由于请求发生重定向，所以一定要加上这行代码，设置自动跳转，否则会返回 302
    //req.setAttribute(QNetworkRequest::FollowRedirectsAttribute, true);
    //    req.setRawHeader("Accept","text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");
    //    req.setRawHeader("User-Agent","Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36");
    //get方式发送请求
    reply = manager->get(req);
    //将服务器的返回信号与replyFinished槽连接起来，当服务器返回消息时，会在槽里做相应操作
    connect(reply,&QNetworkReply::finished,this,&WebSearch::replyFinished);
}
void WebSearch::replyFinished()
{
    // <1>判断有没有错误
    if (reply->error() || search_result == false){
        qDebug()<<reply->errorString();
        reply->deleteLater();
        eventLoop.quit();
        return;
    }

    // <2>检测网页返回状态码，常见是200，404等，200为成功
    int statusCode  = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
    qDebug() << "statusCode:" << statusCode;

    // <3>判断是否需要重定向
    if (statusCode >= 200 && statusCode <300){
        // ok
        // 准备读数据
        QTextCodec *codec = QTextCodec::codecForName("utf8");
        web_data = codec->toUnicode(reply->readAll());
        //qDebug() << "接收到的数据" <<web_data;

        // 数据读取完成之后，清除reply
        reply->deleteLater();
        reply = nullptr;

    } else if (statusCode >=300 && statusCode <400){
        // redirect

        // 获取重定向信息
        const QVariant redirectionTarget = reply->attribute(QNetworkRequest::RedirectionTargetAttribute);
        // 检测是否需要重定向，如果不需要则读数据
        if (!redirectionTarget.isNull()) {
            const QUrl redirectedUrl = url.resolved(redirectionTarget.toUrl());

            reply->deleteLater();
            reply = nullptr;

            startRequest(redirectedUrl);
            qDebug()<< "http redirect to " << redirectedUrl.toString();
            return;
        }
    }
    eventLoop.quit();
}

void WebSearch::getVideoTorrentList(QString url_link,
                        QHash<QString,QHash<QString,QString>>& video_torrent_data,
                        QHash<QString,QList<QString>>& video_name)
{
    QUrl url(url_link);
    QNetworkRequest req;
    req.setUrl(url);
    req.setHeader(QNetworkRequest::ContentTypeHeader, "application/x-www-form-urlencoded");
    req.setAttribute(QNetworkRequest::FollowRedirectsAttribute, true);

    reply = manager->get(req);
    QEventLoop eventLoop;
    QObject::connect(reply, SIGNAL(finished()), &eventLoop,SLOT(quit()));
    // 进入等待，但事件循环依然进行
    eventLoop.exec();

    if (reply->error() != QNetworkReply::NoError) {
        qDebug()<< reply->error();
        return;
    }
    QString con = reply->readAll();
    //qDebug() << con;
    int start_index = 0;
    int end_index = con.indexOf("★★BT天堂★★app版：&nbsp;&nbsp;安装APP不迷路不失联");
    int tab_index_value = 1;
    while((start_index = con.indexOf(tr("【下载地址%1】").arg(tab_index_value))) != -1)
    {
        qDebug() << tr("【下载地址%1】").arg(tab_index_value) << start_index;
        start_index += 7;
        con = con.mid(start_index,end_index-start_index);
        int uri_length = 0;
        start_index = con.indexOf("<a href=\"");
        int tab_index = con.indexOf("【下载地址");
        qDebug() << "tab_index" <<tab_index;
        QHash<QString,QString> video_torrent_data_list;
        QList<QString> video_name_list;
        int current_size = 0;
        while((start_index != -1) && (tab_index > start_index))
        {
            start_index = start_index + 9;
            uri_length = 0;
            while(con[start_index+uri_length] != "\"")
            {
                uri_length++;
            }
            QString link = con.mid(start_index, uri_length);
            //qDebug() << link;
            start_index = start_index + uri_length + 2;
            con = con.mid(start_index,end_index-start_index);
            int index = con.indexOf("</a>");
            QString name = con.mid(0, index);
            //qDebug() << name;
            video_torrent_data_list.insert(name, link);
            video_name_list.append(name);
            start_index = con.indexOf("<a href=\"");
            tab_index = con.indexOf("【下载地址");
            qDebug() << "start_index" <<start_index;
            current_size++;
            if(current_size>20)
                break;
        }
        QString source_path = (tr("【下载地址%1】").arg(tab_index_value));
        video_torrent_data.insert(source_path, video_torrent_data_list);
        video_name.insert(source_path, video_name_list);
        tab_index_value++;
        if(tab_index_value>2)
            break;
    }
}
