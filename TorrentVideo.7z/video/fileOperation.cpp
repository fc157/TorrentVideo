﻿#include "fileOperation.h"
#include <iostream>
#include <QFile>
#include <QDebug>
FileOperation::FileOperation()
{

}
FileOperation::~FileOperation()
{

}

void FileOperation::getWebLink(QHash<QString,QString>& ret)
{
    bool res;
    QFile file("webLink.txt");
    res = file.open(QIODevice::ReadWrite);
    if(res == true)
    {
        QByteArray con=file.readAll();
        qDebug()<< "con: " <<con;
        // 按指定编码格式修改获取的数据
        QString QSdata = QString::fromLocal8Bit(con);
        qDebug()<< "getWebLink: " <<QSdata;
        parsingWebLink(ret, QSdata);

    }
    else{
        qDebug()<< "open fail";
    }
    file.close();
}

void FileOperation::parsingWebLink(QHash<QString,QString>& ret, QString& source_data)
{
    int index = 0;
    QString name = "";
    for (int i = 0; i < source_data.length(); ++i)
    {
        if(source_data[i] == '@')
        {
            name = source_data.mid(index, i-index);
            index = i;
        }
        else if(source_data[i] == '\n')
        {
            QString y = source_data.mid(index+1, i-index-2);
            qDebug()<< "add source web:  " << name;
            ret.insert(name, y);
            index = i+1;
        }
    }
}

