﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>
#include <QHash>
#include <QListView>
#include <QLineEdit>
#include <QPushButton>
#include "webSearch.h"
#include <QTabWidget>
#include "videoview.h"
#include <QLabel>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    void init(QHash<QString,QString>& source_web_link);
    void destroy();
    ~MainWindow();

private:
    void initVideoView();
    void initSourceWebList();
    void initSearchDataList();
    void initVideoTorrentList();
    void sourceWebListItemClick(const QModelIndex &index);
    void searchDataItemClick(const QModelIndex &index);
    void videoTorrentListItemClick(const QModelIndex &index);
    void searchClick();
    QHash<QString,QString> source_web_link;
    Ui::MainWindow *ui;
    QListView *source_web_list;

    QListView *search_data_list;
    //QListView *video_torrent_list;

    QLineEdit* search_box;
    QPushButton* search_button;
    WebSearch* msearch;
    QHash<QString,QVector<MuItemData>> web_data;
    QHash<QString,QHash<QString,QString>> video_torrent_data;
    QTabWidget* web_video_tabwidget;
    QLabel *lable;
    int current_index;
    VideoView* video_view;
    //QHash<QString,QString>::const_iterator current_index;
};
#endif // MAINWINDOW_H
