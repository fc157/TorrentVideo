﻿#ifndef VIDEOVIEW_H
#define VIDEOVIEW_H

#include <QWidget>
#include <QPushButton>
#include <QtMultimedia>
#include <QVideoWidget>
#include "playerslider.h"
#include "mytorrent.h"

namespace Ui {
class VideoView;
}

class VideoView : public QWidget
{
    Q_OBJECT

public:
    explicit VideoView(QWidget *parent = nullptr);
    ~VideoView();

    void init();
    void deinit();
    void startDownload(QString video_torrent);
    void buttonClick();
    bool            m_bReLoad;

public slots:
    void            OnSetMediaFile(void);
    void            OnSlider(qint64);
    void            OnDurationChanged(qint64);
    void            OnStateChanged(QMediaPlayer::State);
    void            OnMediaStatusChanged(QMediaPlayer::MediaStatus);
    void            OnError(QMediaPlayer::Error);
    void            updatePosition(qint64 position);
    void            startPlay();
private:
    void initTorrent();
    void initVideo();
    void updateDownLoadQueue();

    Ui::VideoView *ui;
    QVideoWidget* m_pPlayerWidget;
    QMediaPlayer* m_pPlayer;
    bool is_download;
    qint64 duration;
    int video_piece_start_index;
    int video_piece_end_index;
    MyTorrent* my_torrent;

};

#endif // VIDEOVIEW_H
