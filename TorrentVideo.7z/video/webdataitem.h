﻿#ifndef WEBDATAITEM_H
#define WEBDATAITEM_H

#include <QMetaType>
#include <QString>
#include <QStyledItemDelegate>
#include <QByteArray>
typedef struct {
    QString link;
    QByteArray icon_data;
    QString name;
    QString message;
} MuItemData;

Q_DECLARE_METATYPE(MuItemData);


class WebDataItem : public QStyledItemDelegate
{
public:
    WebDataItem(QObject *parent = nullptr);

    // painting
    void paint(QPainter *painter,
               const QStyleOptionViewItem &option, const QModelIndex &index) const Q_DECL_OVERRIDE;

    QSize sizeHint(const QStyleOptionViewItem &option,
                   const QModelIndex &index) const Q_DECL_OVERRIDE;
};



#endif // WEBDATAITEM_H
