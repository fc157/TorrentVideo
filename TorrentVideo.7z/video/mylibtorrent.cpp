#include "mylibtorrent.h"

MyLibtorrent::MyLibtorrent()
{

}
