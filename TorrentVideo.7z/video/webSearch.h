﻿#ifndef WEBSEARCH_H
#define WEBSEARCH_H
#include <QString>
#include <QHash>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QUrl>
#include <QNetworkReply>
#include <QObject>
#include <QEventLoop>
#include <QJsonDocument>
#include <QVector>
#include <QTimer>
#include "webdataitem.h"
class WebSearch : public QObject
{
public:
    WebSearch();
    WebSearch(QHash<QString,QString>& web_data);
    ~WebSearch();
    void getSearchData(QString name, QHash<QString,QVector<MuItemData>>& ret_web);

    void startRequest(const QUrl &requestedUrl);
    void replyFinished();
    void getVideoTorrentList(QString url_link ,
                             QHash<QString,QHash<QString,QString>>& video_torrent_data,
                             QHash<QString,QList<QString>>& video_name);

private:
    void getSearchDataForBTtiantang(QString name, QVector<MuItemData>& vec_data);
    void getSearchDataForYyets(QString name);
    QUrl url;
    QString web_data;
    QNetworkReply *reply;
    QNetworkAccessManager *manager;
    QHash<QString,QString> web_link;
    QEventLoop eventLoop;
    QJsonDocument mQJsonDocument;
    QTimer timer;
    bool search_result;
};

#endif // WEBSEARCH_H
