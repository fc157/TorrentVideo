﻿#include "mytorrent.h"
#include <QCoreApplication>
MyTorrent::MyTorrent()
{

}
lt::storage_mode_t allocation_mode = lt::storage_mode_sparse;
std::string save_path(".");
int torrent_upload_limit = 0;
int torrent_download_limit = 0;
std::string monitor_dir;
int poll_interval = 5;
int max_connections_per_torrent = 50;
bool seed_mode = false;
bool stats_enabled = false;
int cache_size = -1;

bool share_mode = false;
bool disable_storage = false;

bool quit = false;
//打印出来的大小是以byte为单位
std::string to_hex(lt::sha1_hash const& s)
{
    std::stringstream ret;
    ret << s;
    return ret.str();
}

std::string path_append(std::string const& lhs, std::string const& rhs)
{
    if (lhs.empty() || lhs == ".") return rhs;
    if (rhs.empty() || rhs == ".") return lhs;

#if defined(TORRENT_WINDOWS) || defined(TORRENT_OS2)
#define TORRENT_SEPARATOR "\\"
    bool need_sep = lhs[lhs.size()-1] != '\\' && lhs[lhs.size()-1] != '/';
#else
#define TORRENT_SEPARATOR "/"
    bool need_sep = lhs[lhs.size()-1] != '/';
#endif
    return lhs + (need_sep?TORRENT_SEPARATOR:"") + rhs;
}

std::string resume_file(lt::sha1_hash const& info_hash)
{
    return path_append(save_path, path_append(".resume"
                                              , to_hex(info_hash) + ".resume"));
}

bool load_file(std::string const& filename, std::vector<char>& v
               , int limit = 8000000)
{
    std::fstream f(filename, std::ios_base::in | std::ios_base::binary);
    f.seekg(0, std::ios_base::end);
    auto const s = f.tellg();
    if (s > limit || s < 0) return false;
    f.seekg(0, std::ios_base::beg);
    v.resize(static_cast<std::size_t>(s));
    if (s == std::fstream::pos_type(0)) return !f.fail();
    f.read(v.data(), v.size());
    return !f.fail();
}

void set_torrent_params(lt::add_torrent_params& p)
{
    p.max_connections = max_connections_per_torrent;
    p.max_uploads = -1;
    p.upload_limit = torrent_upload_limit;
    p.download_limit = torrent_download_limit;

    if (seed_mode) p.flags |= lt::torrent_flags::seed_mode;
    if (disable_storage) p.storage = lt::disabled_storage_constructor;
    if (share_mode) p.flags |= lt::torrent_flags::share_mode;
    p.save_path = save_path;
    p.storage_mode = allocation_mode;
}

void MyTorrent::init()
{
    std::string torrent_file_path = "D:/WorkSoftware/QT/project/torrent/Sintel.torrent";
    lt::error_code ec;
    ti = std::make_shared<lt::torrent_info>(torrent_file_path, ec);
    if (ec)
    {
        std::printf("failed to load torrent \"%s\": %s\n"
                    , torrent_file_path.c_str(), ec.message().c_str());
    }
    qDebug() << "total_size:" <<ti->total_size();


    qDebug() << "num_files :" <<ti->num_files();
    lt::file_storage ff = ti->files();

    QString q_str;
    for (int var = 0; var < ti->num_files(); ++var) {
        std::string ss(ff.file_name(var));
        q_str = QString::fromStdString(ss);
        qDebug() << "file name "<<var<<":"<<q_str;
        //qDebug() << "file_size "<<var<<":"<<ff.file_size(var);
        q_str = q_str.mid(q_str.size() - 3 , 3);
        //qDebug() << "q_str :"<<q_str;
        if(q_str.compare("mp4") == 0)
        {
            std::tuple mtuple = lt::aux::file_piece_range_inclusive(ff, var);
            video_piece_start_index = std::get<0>(mtuple);
            video_piece_end_index = std::get<1>(mtuple);
            qDebug() << "start:" << video_piece_start_index << "; end:" << video_piece_end_index;
        }
    }
}
void MyTorrent::deinit()
{

}

void MyTorrent::startDownload()
{
    lt::add_torrent_params p;
    std::vector<char> resume_data;
    lt::error_code ec;
    if (load_file(resume_file(ti->info_hash()), resume_data))
    {
        p = lt::read_resume_data(resume_data, ec);
        if (ec) std::printf("  failed to load resume data: %s\n", ec.message().c_str());
    }
    set_torrent_params(p);

    int num_pieces = ti->num_pieces();
    qDebug() << "num_pieces:" <<ti->num_pieces();
    unsigned int high_down_size = ti->total_size()*0.01;
    int high_down_picec_size = high_down_size/ti->piece_length();
    qDebug() << "high_down_picec_size:" <<high_down_picec_size;
    p.ti = ti;
    p.flags &= ~lt::torrent_flags::duplicate_is_error;
    h = ses.add_torrent(std::move(p));
    for (int var = 0; var <= high_down_picec_size; ++var) {
        h.piece_priority(var,lt::top_priority);
        h.set_piece_deadline(var,1);
        h.piece_priority(num_pieces-var,lt::top_priority);
        h.set_piece_deadline(num_pieces-var,1);
    }
    is_download = true;
    qDebug() << "have_piece(num_pieces) :" <<h.have_piece(num_pieces);
    qDebug() << "have_piece(num_pieces-1) :" <<h.have_piece(num_pieces-1);
    qDebug() << "have_piece(0) :" <<h.have_piece(0);
    qDebug() << "have_piece(1) :" <<h.have_piece(1);
    while( 1 )
    {
        QCoreApplication::processEvents();
        if( h.have_piece(high_down_picec_size) && h.have_piece(num_pieces) )
        {
            //要弄个休眠，暂时定1s查询1次
            emit startSignal();
            break;
        }
    }
    qDebug() << "send startSignal";
}

void MyTorrent::updatePosition(float bili)
{
    qDebug() << "updatePosition :" << bili;
    //实现点哪下哪
    int index = (video_piece_end_index - video_piece_start_index)*bili;
    qDebug() << "index :" << index;
    h.clear_piece_deadlines();
    if(index >0)
        index--;
    for(int var = index ;var <= video_piece_end_index; var++){
        h.set_piece_deadline(var,var);
    }
    h.have_piece(index);
    while( 1 )
    {
        QCoreApplication::processEvents();
        if( h.have_piece(index))
        {
            //要弄个休眠，暂时定1s查询1次
            emit playSignal();
            break;
        }
    }
    qDebug() << "send playSignal ";
}

int MyTorrent::getVideoPieceStartIndex()
{
    return video_piece_start_index;
}
int MyTorrent::getVideoPieceEndIndex()
{
    return video_piece_end_index;
}
