﻿#ifndef MYTORRENT_H
#define MYTORRENT_H

#include <cstdio> // for snprintf
#include <cstdlib> // for atoi
#include <cstring>
#include <utility>
#include <deque>
#include <fstream>
#include <regex>
#include <algorithm> // for min()/max()

#include "libtorrent/config.hpp"

#ifdef TORRENT_WINDOWS
#include <direct.h> // for _mkdir and _getcwd
#include <sys/types.h> // for _stat
#include <sys/stat.h>
#endif

#ifdef TORRENT_UTP_LOG_ENABLE
#include "libtorrent/utp_stream.hpp"
#endif

#include "libtorrent/torrent_info.hpp"
#include "libtorrent/announce_entry.hpp"
#include "libtorrent/entry.hpp"
#include "libtorrent/bencode.hpp"
#include "libtorrent/session.hpp"
#include "libtorrent/identify_client.hpp"
#include "libtorrent/alert_types.hpp"
#include "libtorrent/ip_filter.hpp"
#include "libtorrent/magnet_uri.hpp"
#include "libtorrent/peer_info.hpp"
#include "libtorrent/bdecode.hpp"
#include "libtorrent/add_torrent_params.hpp"
#include "libtorrent/time.hpp"
#include "libtorrent/read_resume_data.hpp"
#include "libtorrent/write_resume_data.hpp"
#include "libtorrent/string_view.hpp"
#include "libtorrent/disk_interface.hpp" // for open_file_state
#include "libtorrent/torrent_status.hpp"
#include <QDebug>
#include <QObject>
namespace lt = libtorrent;

class MyTorrent : public QObject
{
    Q_OBJECT    //必须使用宏Q_OBJECT
public:
    MyTorrent();
    void init();
    void deinit();
    void startDownload();
    int getVideoPieceStartIndex();
    int getVideoPieceEndIndex();
    void updatePosition(float bili);
signals:
    void        startSignal();
    void        playSignal();
private:
    lt::torrent_handle h;
    // 创建 session
    lt::session ses;
    std::shared_ptr<lt::torrent_info> ti;
    bool is_download;
    qint64 duration;
    int video_piece_start_index;
    int video_piece_end_index;
};

#endif // MYTORRENT_H
